title: 【bigdata】hive总结
date: '2023-03-16 11:38:48'
updated: '2023-03-16 11:38:48'
tags: [bigdata, hive, 面试]
permalink: /articles/2023/03/16/1678937928724.html
---
hive本质：将hql转成mapreduce

### hive架构原理

![image](https://b3logfile.com/file/2023/03/solo-fetchupload-2478825779580391334-X3DtlWc.png)
1．用户接口：Client
CLI（hive shell）、JDBC/ODBC(java访问hive)、WEBUI（浏览器访问hive）

2．元数据：Metastore
元数据包括：表名、表所属的数据库（默认是default）、表的拥有者、列/分区字段、表的类型（是否是外部表）、表的数据所在目录等；
默认存储在自带的derby数据库中，推荐使用MySQL存储Metastore

3．Hadoop
使用HDFS进行存储，使用MapReduce进行计算。

4．驱动器：Driver

（1）解析器（SQL Parser）：将SQL字符串转换成抽象语法树AST，这一步一般都用第三方工具库完成，比如antlr；对AST进行语法分析，比如表是否存在、字段是否存在、SQL语义是否有误。

（2）编译器（Physical Plan）：将AST编译生成逻辑执行计划。

（3）优化器（Query Optimizer）：对逻辑执行计划进行优化。

（4）执行器（Execution）：把逻辑执行计划转换成可以运行的物理计划。对于Hive来说，就是MR/Spark。

### hive运行机制

![image](https://b3logfile.com/file/2023/03/solo-fetchupload-5273249816659916111-mTGOVw2.png)

Hive通过给用户提供的一系列交互接口，接收到用户的指令(SQL)，使用自己的Driver，结合元数据(MetaStore)，将这些指令翻译成MapReduce，提交到Hadoop中执行，最后，将执行返回的结果输出到用户交互接口。

### 自定义函数

UDF:返回对应值，一对一

UDAF：返回聚类值，多对一

UDTF：返回拆分值，一对多

### 内部表和外部表

![image](https://b3logfile.com/file/2023/03/solo-fetchupload-912170338665350745-uVxG0Vc.jpeg)
1.hive内部表和外部表的区别

内部表：加载数据到hive所在的hdfs目录，删除时，元数据和数据文件都删除

外部表：不加载数据到hive所在的hdfs目录，删除时，只删除表结构。

这样外部表相对来说更加安全些，数据组织也更加灵活，方便共享源数据。

2.什么时候使用内部表,什么时候使用外部表

每天采集的ng日志和埋点日志,在存储的时候建议使用外部表，因为日志数据是采集程序实时采集进来的，一旦被误删，恢复起来非常麻烦。而且外部表方便数据的共享。

抽取过来的业务数据，其实用外部表或者内部表问题都不大，就算被误删，恢复起来也是很快的，如果需要对数据内容和元数据进行紧凑的管理, 那还是建议使用内部表

在做统计分析时候用到的中间表，结果表可以使用内部表，因为这些数据不需要共享，使用内部表更为合适。并且很多时候结果分区表我们只需要保留最近3天的数据，用外部表的时候删除分区时无法删除数据。

### hive on spark

![image](https://b3logfile.com/file/2023/03/solo-fetchupload-10391524576174838139-leHJLfY.png)
