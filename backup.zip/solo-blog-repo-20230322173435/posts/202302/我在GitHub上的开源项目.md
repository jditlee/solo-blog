title: 我在 GitHub 上的开源项目
date: '2023-02-20 18:57:16'
updated: '2023-02-22 16:28:24'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [tmdSurprise_leetcode_hot100](https://github.com/jditlee/tmdSurprise_leetcode_hot100) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/jditlee/tmdSurprise_leetcode_hot100/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/jditlee/tmdSurprise_leetcode_hot100/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/jditlee/tmdSurprise_leetcode_hot100/network/members "分叉数")</span>

leetcode_hot100 python题解



---

### 2. [democloud](https://github.com/jditlee/democloud) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/jditlee/democloud/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/jditlee/democloud/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/jditlee/democloud/network/members "分叉数")</span>

spring cloud demo

