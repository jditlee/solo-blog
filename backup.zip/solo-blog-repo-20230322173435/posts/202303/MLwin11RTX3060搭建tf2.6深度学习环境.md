title: 【ML】win11+RTX3060搭建tf2.6深度学习环境
date: '2023-03-22 16:00:11'
updated: '2023-03-22 16:03:12'
tags: [ML, 运维, GPU, tensorflow]
permalink: /articles/2023/03/22/1679472011598.html
---
# win11+RTX3060搭建tf2.6深度学习环境

### 1.所需软件

- [cuda](https://developer.nvidia.com/cuda-downloads?target_os=Windows&target_arch=x86_64&target_version=11&target_type=exe_local)
- [cudnn](https://developer.nvidia.cn/rdp/cudnn-archive) cudnn下载需要注册账号
- anaconda
- tf2.6.2

### 2.安装cuda

cuda简介：

```
CUDA是NVIDIA发明的一种并行计算平台和编程模型。
它可以通过利用图形处理器(GPU)的能力来显著提高计算性能。

CUDA的开发有以下几个设计目标:
1.为标准编程语言(如C)提供一小组扩展，以实现并行算法的直接实现。
2.使用CUDA C/ c++，程序员可以专注于算法的并行化，而不是把时间花在算法的实现上。
3.支持异构计算，应用同时使用CPU和GPU。
    应用程序的串行部分运行在CPU上，并行部分被卸载到GPU上，
    这样CUDA就可以增量地应用到现有的应用程序上。
    CPU和GPU被视为具有各自内存空间的独立设备。
    这种配置还允许在CPU和GPU上进行同步计算，而无需争夺内存资源。

cuda支持的GPU有数百个内核，这些内核可以同时运行数千个计算线程。
这些核心拥有共享的资源，包括一个寄存器文件和一个共享的内存。
片上共享内存允许运行在这些核心上的并行任务共享数据，而无需通过系统内存总线发送数据
```

安装步骤：双击一直下一步就行

测试：打开cmd,执行命令`nvcc -V`和`nvidia-sim` 查看对应信息

### 3.配置cudnn

cudnn简介：

```
1.cuDNN 8 的新功能
    cuDNN 8 针对 A100 GPU 进行了优化，可提供高达 V100 GPU 5 倍的开箱即用性能，并且包含适用于对话式 AI 和计算机视觉等应用的新优化和 API。
    它已经过重新设计，可实现易用性和应用集成，同时还能为开发者提供更高的灵活性。
 
2.cuDNN 8 的亮点包括
    已针对 NVIDIA A100 GPU 上的峰值性能进行调优，包括全新 TensorFloat-32、FP16 和 FP32
    通过重新设计的低级别 API，可以直接访问 cuDNN 内核，从而实现更出色的控制和性能调优
    向后兼容性层仍然支持 cuDNN 7.x，使开发者能够顺利过渡到新版 cuDNN 8 API
    针对计算机视觉、语音和语言理解网络作出了新优化
    已通过新 API 融合运算符，进而加速卷积神经网络
    cuDNN 8 现以六个较小的库的形式提供，能够更精细地集成到应用中。开发者可以下载 cuDNN，也可从 NGC 上的框架容器中将其提取出来。
 
3.主要特性

    3.1 为所有常用卷积实现了 Tensor Core 加速，包括 2D 卷积、3D 卷积、分组卷积、深度可分离卷积以及包含 NHWC 和 NCHW 输入及输出的扩张卷积
    3.2 为诸多计算机视觉和语音模型优化了内核，包括 ResNet、ResNext、SSD、MaskRCNN、Unet、VNet、BERT、GPT-2、Tacotron2 和 WaveGlow
    3.3 支持 FP32、FP16 和 TF32 浮点格式以及 INT8 和 UINT8 整数格式
    3.4 4D 张量的任意维排序、跨步和子区域意味着可轻松集成到任意神经网络实现中能为任意 CNN 架构上融合的运算提速
    3.5 数据中心采用 Ampere、Turing、Volta、Pascal、Maxwell 和 Kepler GPU 架构以及配备移动 GPU 的 Windows 和 Linux 支持 cuDNN。
```

安装：解压后将各文件夹下的文件复制到cuda安装路径下的对应文件夹里

### 4.conda添加新环境并下载tf2.6

```
# 相关配置
# conda配置国内清华源
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free/
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main/
# 显示下载源
conda config --set show_channel_urls yes
# 查看conda的配置
conda config --show  

# pip配置国内清华源
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 创建并激活环境
conda create tf2_6 python=3.9
conda activate tf2_6

# 安装tf-gpu-2.6.2
pip install tensorflow-gpu==2.6.2


```

### 5.测试gpu

```
import tensorflow as tf

print(tf.__version__) #2.6.2

print(tf.test.is_gpu_available()) # 为True表示安装成功

```

`注意：目前没有手动配置环境变量，如果后续代码有问题可能需要配一下`

#### 【20220617】如果你有幸看到了这里，而且在训练模型的时候遇到了错误，请参考以下博文，西西

[【ML】tensorflow训练卷积神经网络报错 - Neptune (laobiao.fun)](http://www.laobiao.fun/articles/2023/03/22/1679472163095.html)

### 参考文献

- https://cloud.tencent.com/developer/article/1914694
- https://tensorflow.google.cn/install/gpu
- https://docs.nvidia.com/cuda/cuda-installation-guide-microsoft-windows/
- https://docs.microsoft.com/en-us/windows/ai/directml/gpu-accelerated-training
