title: 【bigdata】4.hive安装
date: '2023-03-16 11:15:06'
updated: '2023-03-16 11:17:02'
tags: [bigdata, hive, 运维]
permalink: /articles/2023/03/16/1678936506568.html
---
`hive的全部安装过程都是在master节点`

### 安装hive

#### 1.上传并解压

```
tar -zxvf apache-hive-1.2.2-bin.tar.gz -C /hive安装目录
```

#### 2.配置环境

**2.1 配置hive-env.sh**

```
# 跳转到hive配置文件目录
cd /hive安装目录/conf
# 修改名称
mv hive-env.sh.template hive-env.sh
# 编辑文件
vim hive-env.sh
```

**添加如下内容：**

```
export JAVA_HOME=/java安装目录/jdk1.8.0_172
export HADOOP_HOME=/hadoop安装目录/hadoop-2.6.1
export HIVE_HOME=/hive安装目录/apache-hive-1.2.2-bin
export HIVE_CONF_DIR=/hive安装目录/apache-hive-1.2.2-bin/conf
```

**2.2 配置hive-site.sh**

```
vim hive-site.sh


#添加如下内容
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
    <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://master:3306/hive?createDatabaseIfNotExist=true&useSSL=false</value>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>root</value>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>123456</value>
    </property>
    <property>
        <name>hive.metastore.warehouse.dir</name>
        <value>hdfs://master:9000/hive/warehouse</value>
    </property>
    <property>
        <name>hive.exec.scratchdir</name>
        <value>hdfs://master:9000/hive/tmp</value>
    </property>
    <property>
        <name>hive.querylog.location</name>
        <value>/usr/hive/log</value>
        <description>设置hive job日志存储位置</description>
    </property>
    <property>
        <name>hive.cli.print.header</name>
        <value>true</value>
        <description>设置列名</description>
    </property>
    <property>
        <name>hive.resultset.use.unique.column.names</name>
        <value>false</value>
        <description>增加列名可读性</description>
    </property>
    <!-- flume to hive test-->
    <!--<property>-->
    <!--    <name>hive.support.concurrency</name>-->
    <!--    <value>true</value>-->
    <!--    <description>是否支持并发，默认是false</description>-->
    <!--</property>-->
    <!--
    <property>
        <name>hive.txn.manager</name>
        <value>org.apache.hadoop.hive.ql.lockmgr.DbTxnManager</value>
        <description>打开一部分事务支持协同配置</description>
    </property>
    -->
    <!--支持事务，有问题，可以注释掉-->
    <!--<property>-->
    <!--    <name>hive.compactor.initiator.on</name>-->
    <!--    <value>true</value>-->
    <!--    <description>运行启动程序和清除线程,用于打开所需参数的完整列表事务</description>-->
    <!--</property>-->
    <!--<property>-->
    <!--    <name>hive.compactor.worker.threads</name>-->
    <!--    <value>1</value>-->
    <!--    <description>增加工作线程的数量将减少花费的时间</description>-->
    <!--</property>-->
    <!--<property>-->
    <!--    <name>hive.enforce.bucketing</name>-->
    <!--    <value>true</value>-->
    <!--    <description>是否启用bucketing，写入table数据</description>-->
    <!--</property>-->
    <!--<property>-->
    <!--    <name>hive.exec.dynamic.partition.mode</name>-->
    <!--    <value>nonstrict</value>-->
    <!--    <description>设置动态分区模式为非严格模式</description>-->
    <!--</property>-->
</configuration>

```

**2.3 配置环境变量**

```
vim ~/.bashrc

添加如下内容：
export HIVE_HOME=/hive安装目录/apache-hive-1.2.2-bin
export PATH=$PATH:${HIVE_HOME}/bin

source ~/.bashrc
```

### 安装MySQL

**1.卸载已有mysql/mariadb**
**查找命令：**

```
rpm -qa | grep mysql
rpm -qa | grep mariadb
```

**卸载命令：**

```
rpm -e mysql【一般删除，如果提示以来的其他文件，则不能删除】
rpm -e --nodeps mysql【强制删除，包含各种依赖包】
yum -y remove mysql* 【删除软件的时候会删除对该软件具有依赖关系的包】
【Tips：三种方式任选】
```

**2.下载yum**

```
wget http://mirrors.ustc.edu.cn/mysql-repo/mysql57-community-release-el7-9.noarch.rpm
```

**3.安装**

```
rpm -ivh mysql57-community-release-el7-9.noarch.rpm

yum -y install mysql-community-server

```

**4.关闭强密码验证**

```
vim /etc/my.cnf
# 增加如下内容
plugin-load=validate_password.so
validate-password=OFF
```

**5.启动**

```
service mysqld start
```

**6.修改密码**

```
#查找初始随机密码
grep "password" /var/log/mysqld.log
#eg:A temporary password is generated for root@localhost: r+RWXg*a7e%1

#通过初始随机密码进入mysql
mysql -uroot -p
输入随机密码

#修改密码：
#mysql客户端执行
SET PASSWORD = PASSWORD('123456');
ALTER USER 'root'@'localhost' PASSWORD EXPIRE NEVER;
#刷新
flush privileges;
#退出使用新密码登录
exit

#shell命令执行
mysql -uroot -p123456
```

**7.设置远程访问**

```
#mysql客户端执行
grant all privileges on *.* to root@"%" identified by "123456";
flush privileges;
```

**8.设置开机启动**

```
#shell命令执行
systemctl enable mysqld
```

**9.hive设置mysql连接工具**

```
#获取jar包
wget https://cdn.mysql.com/archives/mysql-connector-java-5.1/mysql-connector-java-5.1.45.tar.gz
#解压
tar -zxvf mysql-connector-java-5.1.45.tar.gz
#进入解压目录
cd mysql-connector-java-5.1.45
#复制连接jar包到hive的lib目录
cp mysql-connector-java-5.1.45-bin.jar $HIVE_HOME/lib/
```

### 安装hive是Jline版本不一致问题

**删除hadoop/share/hadoop/yarn/lib下的jline包，复制hive/lib目录下的jline到hadoop：**

![image](https://b3logfile.com/file/2023/03/image-Cnwm1Gy.png)

### 启动hive

```
#启动hadoop集群
start-all.sh
#启动hive
hive
#启动hiveserver2
hiveserver2
```
