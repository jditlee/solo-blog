title: 【bigdata】Flink总结
date: '2023-03-16 11:45:22'
updated: '2023-03-16 11:45:22'
tags: [bigdata, flink, 面试]
permalink: /articles/2023/03/16/1678938322285.html
---
### Flink 几个最基础的概念:

Client、JobManager 和 TaskManager。Client 用来提交任务给 JobManager，JobManager 分发任务给 TaskManager 去执行，然后 TaskManager 会心跳的汇报任务状态

### 窗口：

stream.timewindow:时间

stream.countwindow:计数

stream.window(SessionWindows.withGap(Time.minutes(5))：会话

### Flink程序的基本构建块是流和转换。

一个程序的基本构成：

l 获取execution environment

l 加载/创建原始数据

l 指定这些数据的转化方法

l 指定计算结果的存放位置

l 触发程序执行

```java
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
public class StreamingJob {

 public static void main(String[] args) throws Exception {
  final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
  DataStream<Tuple2<String, Integer>> dataStreaming = env
    .socketTextStream("localhost", 9999)
    .flatMap(new Splitter())
    .keyBy(0)
    .timeWindow(Time.seconds(5))
    .sum(1);

  dataStreaming.print();

  // execute program
  env.execute("Flink Streaming Java API Skeleton");
 }
 public static class Splitter implements FlatMapFunction<String, Tuple2<String, Integer>> {

  @Override
  public void flatMap(String sentence, Collector<Tuple2<String, Integer>> out) throws Exception {
   for(String word : sentence.split(" ")){
    out.collect(new Tuple2<String, Integer>(word, 1));
   }
  }

 }
}
```

### 官网笔记

#### 流

Flink 的 Java 和 Scala DataStream API 可以将任何可序列化的对象转化为流。Flink 自带的序列化器有

```
基本类型，即 String、Long、Integer、Boolean、Array
复合类型：Tuples、POJOs 和 Scala case classes
```

而且 Flink 会交给 Kryo 序列化其他类型。也可以将其他序列化器和 Flink 一起使用。特别是有良好支持的 Avro。

#### stream执行环境

每个 Flink 应用都需要有执行环境，在该示例中为 env。流式应用需要用到 StreamExecutionEnvironment。

DataStream API 将你的应用构建为一个 job graph，并附加到 StreamExecutionEnvironment 。当调用 env.execute() 时此 graph 就被打包并发送到 JobManager 上，后者对作业并行处理并将其子任务分发给 Task Manager 来执行。每个作业的并行子任务将在 task slot 中执行。

注意，如果没有调用 execute()，应用就不会运行。

![image](https://b3logfile.com/file/2023/03/solo-fetchupload-3494035270768043777-E6F9Est.png)

#### print()

data.print() 打印其结果到 task manager 的日志中（如果运行在 IDE 中时，将追加到你的 IDE 控制台）。它会对流中的每个元素都调用 toString() 方法。

#### 数据管道 & ETL

keyBy()将一个流根据其中的一些属性来进行分区是十分有用的，这样我们可以使所有具有相同属性的事件分到相同的组里。例如，如果你想找到从每个网格单元出发的最远的出租车行程。按 SQL 查询的方式来考虑，这意味着要对 startCell 进行 GROUP BY 再排序，在 Flink 中这部分可以用 keyBy(KeySelector) 实现。

每个 keyBy 会通过 shuffle 来为数据流进行重新分区。总体来说这个开销是很大的，它涉及网络通信、序列化和反序列化。

map() 一对一的流转换

flatmap() 多对一的流转换
