title: 【ML】tensorflow训练卷积神经网络报错
date: '2023-03-22 16:02:43'
updated: '2023-03-22 16:02:43'
tags: [tensorflow, bug, CNN, cudnn]
permalink: /articles/2023/03/22/1679472163095.html
---
在做数字识别实验的时候，使用tensorflow训练卷积神经网络出现了一些错误，记录一下

### 错误一：Process finished with exit code -1073740791 (0xC0000409)

在执行model.fit训练的时候出现了这个错误。
pycharm里面就提示了这个错误，没有详细的错误说明，不好定位问题，要是单独搜索这个错误，会又一大堆解决内存不足的方案给你，但是这都不是我们需要的解决方案。

所以我们需要详细的错误说明，编辑文件配置：
![](https://b3logfile.com/file/2023/03/solo-fetchupload-14923551534325707852-bBWZTLw.png)

勾选Execution里面的emulate terminal in output console
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-7873608054268478203-RBF2bfB.png)

然后我们就能看到详细的报错信息了：
Could not load library cudnn_cnn_infer64_8.dll. Error code 126
Please make sure cudnn_cnn_infer64_8.dll is in your library path

![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-16190309732333158648-BpPKoI9.png)

### 错误二：Could not load library cudnn_cnn_infer64_8.dll. Error code 126

这个是cuda的安装上的一些错误，官方文档中有说明需要安装配置zlib的，但是很多博客都没有说明这个问题：
下载zlib
https://docs.nvidia.com/deeplearning/cudnn/install-guide/index.html#install-zlib-windows
在这里找到下载连接，
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-6216164494059626957-khbPG7u.png)

下载zlib并解压，然后复制zlibwapi.dll到C:\Windows\System32下面

然后应该就能解决这个问题了

如果还是报错，应该是zlib安装的问题，百度zlib的安装吧，当然，这边建议先重启呢，亲
