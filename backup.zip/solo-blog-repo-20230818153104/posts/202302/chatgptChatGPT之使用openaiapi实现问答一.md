title: 【chatgpt】ChatGPT之使用open-ai api实现问答（一）
date: '2023-02-20 15:42:04'
updated: '2023-03-27 19:34:54'
tags: [ChatGPT, python, AIGC, nlp]
permalink: /articles/2023/02/20/1676878924135.html
---
```python
import os
import openai

# openai.api_key = os.getenv()
openai.api_key = "sk-******************************"

question = "Q:什么是神经网络\n A:"


def generate_prompt(question):
    return """我是一个高度智能的问答机器人。如果你问我一个植根于真理的问题，我会给你答案。如果你问我一个无稽之谈、诡计多端或没有明确答案的问题，我会回答“未知”。\nQ:{}\nA:""".format(question)


response = openai.Completion.create(
    # model="text-ada-001",
    # model="text-curie-001",
    # model="text-babbage-001",
    model="text-davinci-003", # 对话模型的名称
    prompt=generate_prompt(question),
    temperature=1,# 值在[0,1]之间，越大表示回复越具有不确定性
    max_tokens=2048, # 回复最大的字符数
    frequency_penalty=0,# [-2,2]之间，该值越大则更倾向于产生不同的内容
    presence_penalty=0,# [-2,2]之间，该值越大则更倾向于产生不同的内容
    user='user530'
)
print(response['choices'][0]['text'])
```
