title: Linux纯命令行配置clash，自由访问GPT api
date: '2023-05-30 17:08:35'
updated: '2023-05-30 17:14:56'
tags: [科学上网, clash, github, 运维]
permalink: /articles/2023/05/30/1685437715197.html
---
![](https://b3logfile.com/bing/20181112.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

clash真是难用啊，文档也不好好写，Linux上配置却叫我浏览器访问设置节点。。。

搞了两天终于配置起来了，安装clash的教程基本都千篇一律吧，主要重点在如何命令行配置网络代理，没有一篇教程说明是如何命令行配置的。。。大家服务器都是桌面版的吗，头大

我服务器的操作系统是Ubuntu

# 安装clash

老三样，下载，解压，安装

```shell
# 下载clash，Github地址：https://github.com/Dreamacro/clash/releases
# 两种方式：
# 1.访问GitHub本地下载了上传到服务器，网络不好的建议此方式
# 2.wget 命令服务器下载
wget https://github.com/Dreamacro/clash/releases/download/v1.16.0/clash-linux-amd64-v1.16.0.gz

# 解压
gzip -d clash-linux-amd64-v1.16.0.gz

# 解压之后就是二进制执行文件了，不需要安装，修改一下权限，然后执行：
# 修改权限
sudo chmod +x clash-linux-amd64-v1.16.0
# 执行
./clash-linux-amd64-v1.16.0
# 执行会在~/.config/clash目录下生成config.yaml和Country.mmdb文件
# 如果报错下载Conutry.mmdb文件失败，可以手动下载，地址：https://www.sub-speeder.com/client-download/Country.mmdb

wget -O Country.mmdb https://www.sub-speeder.com/client-download/Country.mmdb
# 然后将Country.mmdb移动到~/.config/clash目录下
mv Country.mmdb ~/.config/clash/
# 为了方便执行和统一管理，我们将clash可执行文件移动到~/.config/clash并重命名为clash
cp clash-linux-amd64-v1.16.0 ~/.config/clash/clash
```

# 配置网络代理

就是这一步卡了很久，网上的文章都是说桌面系统如何配置，有文章说命令行怎么配置的也是错的。。。

首先获取代理商提供的订阅链接，即config.yaml文件

`wget -O config.yaml 代理商订阅链接地址`

然后就是用此文件替换~/.config/clash下的同名文件

`cd ~/.config/clash`

启动clash

`./clash`

出现如下界面即为成功

![image.png](https://b3logfile.com/file/2023/05/image-N5UONfj.png)

这里启动之后窗口就不要关闭了，如果要配置后台运行，自行百度，可以配置一个服务开机自启。

重新打开一个窗口

然后就是最重要的一步，这一步卡了很久。。。配置网络代理，clash启动成功之后只是提供了端口科学上网，还需要配置网络请求通过代理地址访问才算成功

`vi ~/.bashrc`

在文件末尾添加如下内容：

```shell
alias proxy_on="export https_proxy=127.0.0.1:7890 && export http_proxy=127.0.0.1:7890"
alias proxy_off="unset http_proxy https_proxy"
```

：wq保存`source ~/.bashrc`使配置生效

然后就是执行命令`proxy_on`开启代理，就可以愉快的上网了

测试一下，`curl https://www.google.com`

同理，关闭代理命令：`proxy_off`

## 配置一下GitHub加速

```shell
git config --global http.proxy 'http://127.0.0.1:7890'
git config --global https.proxy 'http://127.0.0.1:7890'
```
