title: LLM微调实战，做自己的chatgpt (一）
date: '2023-05-31 17:47:46'
updated: '2023-05-31 18:00:25'
tags: [LLAMA, ChatGPT, 华佗, 开源]
permalink: /articles/2023/05/31/1685526466456.html
---
最近在做开源LLM在医疗垂直领域的finetune实验，通过开源项目[华佗](https://github.com/SCIR-HI/Huatuo-Llama-Med-Chinese)来总结一下具体的一个finetune技术路线。

该项目开源了经过中文医学指令精调/指令微调(Instruct-tuning) 的LLaMA-7B模型。通过医学知识图谱和GPT3.5 API构建了中文医学指令数据集，并在此基础上对LLaMA进行了指令微调，提高了LLaMA在医疗领域的问答效果。

## 1. 环境搭建

下载[华佗](https://github.com/SCIR-HI/Huatuo-Llama-Med-Chinese)开源代码

安装依赖包，python环境建议3.9+

```
# 在conda下创建虚拟环境
conda create -n huatuo python==3.9
# 激活环境
conda activate huatuo
# 安装依赖
pip install -r requirements.txt
# 安装的时候会出现git+依赖包安装不上的情况
# 手动下载github zip包，然后上传到服务器，也可以clone GitHub包
# 克隆项目
git clone https://github.com/xxx/xxx.git
# 切换目录
cd xxx
# 从源项目有构建
python setup.py install


```

## 2. 权重下载

官方提供了训练好的LoRA权重下载，可以通过百度网盘或Huggingface下载：

1. 对LLaMA进行指令微调的LoRA权重文件

* 基于医学知识库 [百度网盘]([https://pan.baidu.com/s/1jih-pEr6jzEa6n2u6sUMOg?pwd=jjpf)和[HuggingFace](https://pan.baidu.com/s/1jih-pEr6jzEa6n2u6sUMOg?pwd=jjpf)%E5%92%8C[HuggingFace)]([https://huggingface.co/thinksoso/lora-llama-med](https://huggingface.co/thinksoso/lora-llama-med))
* 基于医学文献 [百度网盘](https://pan.baidu.com/s/1jADypClR2bLyXItuFfSjPA?pwd=odsk)

2. 对Alpaca进行指令微调的LoRA权重文件

* 基于医学知识库 [百度网盘](https://pan.baidu.com/s/16oxcjzXnXjDpL8SKihgNxw?pwd=scir)
* 基于医学知识库和医学文献 [百度网盘](https://pan.baidu.com/s/1HDdK84ASHmzOFlkmypBIJw?pwd=scir)

下载LoRA权重并解压，解压后的格式如下：

```
#1.对LLaMA进行指令微调的LoRA权重文件
#基于医学知识库
lora-llama-med/
  - adapter_config.json   # LoRA权重配置文件
  - adapter_model.bin   # LoRA权重文件

#基于医学文献
lora-llama-med-literature/
  - adapter_config.json   # LoRA权重配置文件
  - adapter_model.bin   # LoRA权重文件


#2. 对Alpaca进行指令微调的LoRA权重文件
#基于医学知识库
lora-alpaca-med-alpaca/
  - adapter_config.json   # LoRA权重配置文件
  - adapter_model.bin   # LoRA权重文件

#基于医学知识库和医学文献
lora-alpaca-med-alpaca-alldata/
  - adapter_config.json   # LoRA权重配置文件
  - adapter_model.bin   # LoRA权重文件
```

## 3.模型推理实验

在`./data/infer.json`中提供了一些测试用例，可以替换成其它的数据集，请注意保持格式一致

运行infer脚本

```
#基于医学知识库
bash ./scripts/infer.sh

#基于医学文献
#单轮
bash ./scripts/infer-literature-single.sh

#多轮
bash ./scripts/infer-literature-multi.sh
```

也可参考`./scripts/test.sh`

## 4.Finetune

如果想用自己的数据集微调LLaMA，按照`./data/llama_data.json`的格式构建自己的数据集

运行finetune脚本

```

bash ./scripts/finetune.sh

```

## 5.训练细节

### 计算资源需求

官方在一张A100-SXM-80GB显卡上进行了训练，训练总轮次10轮，耗时约2h17m。batch_size=128的情况下显存占用在40G左右。预计3090/4090显卡(24GB显存)以上显卡可以较好支持，根据显存大小来调整batch_size。

我使用的是48G的A40，batch_size=64，显存占用43g，训练10轮花了8个小时左右。深度时代，拼的就是机器呀。。。

### 实验过程

超参设置和实验过程可以参考wandb的链接:

[https://wandb.ai/thinksoso/llama_med/runs/a5wgcnzt/overview?workspace=user-thinksoso](https://wandb.ai/thinksoso/llama_med/runs/a5wgcnzt/overview?workspace=user-thinksoso)

## 6.模型效果对比


| 测试输入                                                                                   | Llama输出                                                                      | Alpaca输出                                                                                 | 华佗输出                                                                                                   |
| -------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| 小张最近感觉身体不适，出现心悸、气促等症状。体检发现心脏扩大、搏动减弱。                   | 问题：小张最近感觉身体不适，出现心悸、气促等症状。体检发现心脏扩大、搏动减弱。 | 最近，小张一直感觉身体不舒服，有心烦意乱、呼吸急促等症状。体格检查显示心脏增大，肌肉无力。 | **小张可能患有心肌炎，建议尽快到医院进行检查和治疗。治疗方案包括药物治疗和手术治疗。**                     |
| 麻风病和儿童哮喘的病因是否一致？                                                           | 儿童哮喘和麻风病的病因是一致，但是儿童哮喘和麻风病的病因不一致                 | 是的，哮喘和儿童喘息有相似的原因。                                                         | **不一致，麻风病的病因是麻风杆菌感染，而儿童哮喘的病因是喂养不良、吸烟等因素。**                           |
| 一位患者出现了持续性的胀痛和黄疸，经影像学检查后确诊为肝胆管结石病，应该采取哪些治疗方案？ | 肝胆管结石病患者应该采取哪些治疗方案？                                         | 患者应接受手术和化疗相结合的治疗。                                                         | **针对肝胆管结石病，治疗方案包括手术治疗、药物治疗和辅助治疗等。具体治疗方案需要根据患者的具体情况而定。** |

## 7. 问题记录

1. 环境问题，git+依赖安装不上，配置科学上网了也是不行，解决办法在[1.环境搭建]()中已经说明
2. finetune的时候重载checkpoints会报错模型为空，代码里面调用peft的set_peft_model_state_dict方法有bug，最新版的peft该方法没有返回值，官方代码也不知道那里copy来的。。。
3. 最后保存模型的时候调用`trainer.train(resume_from_checkpoint=resume_from_checkpoint)`报错，降低transformer版本解决，但是保存的权重值和官方有出入，可能官方也没有给全部的训练数据
4. 体验下来会有重复说话的情况，而且鉴于数据质量，答案也比较差，还需要投喂更多的优质数据
5. 强依赖训练数据集，几乎是复读机了

参考：

[SCIR-HI/Huatuo-Llama-Med-Chinese: Repo for BenTsao [original name: HuaTuo (华驼)], Llama-7B tuned with Chinese medical knowledge. 本草（原名：华驼）模型仓库，基于中文医学知识的LLaMA模型指令微调 (github.com)](https://github.com/SCIR-HI/Huatuo-Llama-Med-Chinese)
