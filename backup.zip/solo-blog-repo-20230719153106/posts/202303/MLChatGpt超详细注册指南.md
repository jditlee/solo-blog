title: 【ML】ChatGpt超详细注册指南
date: '2023-03-24 14:19:28'
updated: '2023-03-24 14:19:50'
tags: [ChatGPT, ML, 接码平台]
permalink: /articles/2023/03/24/1679638768350.html
---
![](https://b3logfile.com/bing/20181221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 准备

1.科学上网工具。香港节点不行。我这边日本，韩国的也不行了，目前用的美国的

2.接码平台，如果你没有用过接码平台找一个国外手机号码也行，有些接码平台是无法接的，推荐sms-activate.org

## 注册流程

#### 第一步注册接码平台账户

打开接码平台 https://sms-activate.org/，注册一个账号：
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-11975770242591254040-HnsST3g.png)然后要充值余额
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-16509018023390046177-AOU5Oep.png)
充值，这里单位是卢布
一次接码OpenAi的验证码费用是大概11卢布，人民币来看差不多是1块钱，不过只能充美金，就先充直个1美金钱。可以选择对你方便的任何方式。有支付宝
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-11852765182179967450-Y4ZfaLb.png)充值完成可能需要等一会，就先放着，直接进行下一步。

#### 第二步注册openAI账号

打开gpt官网，点击注册：https://chat.openai.com/auth/login
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-13282572458061060687-O03JCKZ.png)
这里可以用邮箱，如果有谷歌或者微软账号也可以直接用，免去邮箱验证的环节。
用邮箱注册后你要验证邮件。进去邮箱，查看email里的链接。
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-4678384807029052665-JZ7bm5c.png)
输入相关信息
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-17390405386638961464-llS1cCI.png)
然后就是验证手机号
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-5920542020340237590-Sp0e8VY.png)
这里就需要去接码网站上去租手机号了，大家自己找便宜的租：
选择国家（俄罗斯的不行），输入服务openai，点击出租
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-15322501201314974320-tivarbw.png)
然后就租到了相应的手机号
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-10779876878203937106-uS4Qg6w.png)
复制手机号，然后回到open验证手机号，发送的验证码会在解码平台显示，复制粘贴，然后就注册好了，如果手机号也不能用，赶紧回到接码平台点击拒绝，费用会退回，我用的德国的手机号

这里就随便选择了
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-15489862186120210551-mSnd7Oh.png)
注册完成之后，打开chatgpt网站（https://chat.openai.com）就可以登陆体验了
![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-11258291094618771057-je5sLdb.png)

## 错误解决

#### 不能在当前国家服务

![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-18265938111094151684-kbAodmS.png)
一般你出现这种问题，就是因为你的代理没有全局，或者位置不对。香港或中国的的代理是100%无法通过的。
这个问题是非常神奇的，只要你出现了这个提示，那么你接下来怎么切换代理，都是没用的。现在提供给你你一招解决。
首先，你要把你的代理切换到任何合适的地区，我们这里选择了美国。
然后，先复制下面这段代码
`window.localStorage.removeItem(Object.keys(window.localStorage).find(i=>i.startsWith('@@auth0spajs')))`
接着在地址栏里输入
`javascript:`
请注意，这里一定要输入，因为你复制的话是粘贴不了的。
然后再粘贴我们第一段复制的内容：
然后按下回车键，刷新页面。如果你的代理没问题，就可以看到正常工作的注册页面了。

#### 访问被拒绝

![在这里插入图片描述](https://b3logfile.com/file/2023/03/solo-fetchupload-14021276370594671352-tUk7Ngz.png)
这种情况切换其它国家节点
