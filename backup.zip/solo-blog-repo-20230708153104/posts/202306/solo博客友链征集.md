title: solo博客友链征集
date: '2023-06-01 18:14:28'
updated: '2023-06-01 18:14:28'
tags: [solo, 友链, blog]
permalink: /articles/2023/06/01/1685614468233.html
---
这是一篇征集友链的帖子，主要是为了让我的友链闲得不那么孤独

![image.png](https://b3logfile.com/file/2023/06/image-RVnHVcE.png)

我的主页：http://www.laobiao.fun/

留言互链
