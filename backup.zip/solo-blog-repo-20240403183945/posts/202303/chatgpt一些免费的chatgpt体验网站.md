title: 【chatgpt】一些免费的chatgpt体验网站
date: '2023-03-27 19:32:08'
updated: '2023-03-30 15:27:50'
tags: [ChatGPT, ML, Neptune, 凌陨心]
permalink: /articles/2023/03/27/1679916728841.html
---
## 1.[chatgpt](https://chat.openai.com)

原生网站，chatgpt免费使用，但是注册需要国外手机号，还有科学上网

要体验GPT-4需要购买plus，需要国外信用卡，而且，PLUS 用户登陆 ChatGPT 时需有高质量原生IP，中国大陆和香港网络并不支持。另外低质量节点会因 IP 问题被 ban 显示禁止访问，必要时请选择全局模式。

## 2.[Poe](https://poe.com)

一个综合的gpt体验平台，还可以体验**GPT-4**和**Claude+**，一天一次。。。

其它模型无限制，同样需要科学上网，任意邮箱登录即可。

主要有以下模型：

* **Claude**在许多创意写作任务上表现更好，但更有可能拒绝回答问题。
* **Claude+**比**Claude**显著更好，特别是在非英语语言方面。在英语方面，它生成的答案比Claude更深入。
* **Sage**和**ChatGPT**在英语以外的语言方面表现更好，并且在编程相关任务方面表现更好。
* **Dragonfly**往往会给出更短的回答，并且当给出输入示例时，更容易让Dragonfly遵循指示。
* **GPT-4**相对于**ChatGPT**是一项重大进步，是当今世界上最强大的语言模型。它特别擅长创意写作、问题解决（例如数学和物理）和指令跟随。

每个机器人都有独特的个性，您可以随着时间的推移了解它们，因此，如果您感兴趣，可以尝试它们并决定自己最喜欢哪个。

## 3.[cursor](https://www.cursor.so)

Cursor是一款用于编程的AI编辑器，官网下载即用。现在还处于早期阶段，但是现在Cursor可以帮助你完成一些事情：

* code：使用比Copilot更智能的AI生成10-100行代码
* 优化：要求AI编辑一块代码，只看到建议的更改
* chat：ChatGPT风格的界面，可以理解您当前的文件
* more：要求修复lint错误，在悬停时生成测试/注释等。

持续更新。。。

## 4.[【博弈Ai】ChatGPT非官方国产镜像 (bo-e.com)](https://ai.bo-e.com/)

稳定，模仿chatgpt界面

## 5. [https://chat2.yqcloud.top/](https://chat2.yqcloud.top/)

## 6.[Ext导航Chat机器人 (extnav.com)](https://extnav.com/chatbot/one/#/chat/1002)

## 7.[TDChat_ChatGPT免登录账号版_土豆Chat_AI助手_AI绘图_基于OpenAI API实现 (tdchat2.com)](http://www.tdchat2.com/)

## 8.[仅用于开发学习交流 (yqcloud.top)](https://chat2.yqcloud.top/#/chat/1679990537407)

## 9.[ChatGPT Web (aiai.zone)](https://www.aiai.zone/#/chat/1002)

## 10.[ChatGPT (usesless.com)](https://ai.usesless.com/scene)

## 11.https://chat1.wuguokai.top/s/chatgpt

## 12.[GeekChat - 支持文字、语音、翻译、画图的免费体验版ChatGPT (geekr.dev)](https://gpt.geekr.dev/)
