title: 【bigdata】1.hadoop集群搭建
date: '2023-03-16 11:07:50'
updated: '2023-03-16 11:07:50'
tags: [bigdata, hadoop, 大数据集群, 运维]
permalink: /articles/2023/03/16/1678936070647.html
---
## 安装虚拟机

* 打开VMware-》文件-》新建虚拟机：
* 默认典型，下一步
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-6630022845724096305-TgQO57k.png)
* 选择镜像文件位置，下一步
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-4519374331044405911-Q4bCtdL.png)
* 设置用户名密码，下一步（注意，有些镜像是在安装过程中设置，我用的镜像是：CentOS-7-x86_64-DVD-1804.iso，18年版本的都能先设置用户名密码，后面全程自动安装）
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-7304592650664793623-ZBMFsCy.png)
* 设置虚拟机名称和位置，下一步
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-5263692463146660490-GXvXxyj.png)
* 设置磁盘大小，下一步
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-16912712305893734598-rYy2MfT.png)
* 默认配置，点击完成，然后就等待系统安装完成（其它硬件配置可以后面再修改）
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-4129298951286334513-1H1HkTP.png)
* 虚拟机配置修改，网络连接选择NAT模式，其他配置根据自己电脑情况修改
  ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-1134304617427973753-LRqGK1C.png)

## 配置ip，hostname

1. 打开VMware-》编辑-》虚拟网络编辑器
   设置子网ip：
   ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-17207356313345203235-BxUBRJA.png)
   点击NAT设置，设置网关地址（这里的网关地址就是虚拟机里面需要配置的网关地址）：
   ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-7733818912077240570-CfQatTi.png)
   点击DHCP设置，设置IP地址的范围：
   ![image](https://b3logfile.com/file/2023/03/solo-fetchupload-1057032575902276084-mdNtgiy.png)
2. 打开创建好的虚拟机，配置IP地址：

```
vim /etc/sysconfig/network-scripts/ifcfg-ens33
-- 修改以下配置
ONBOOT=yes
BOOTPROTO=static
IPADDR=192.168.1.101
GATEWAY=192.168.1.2
DNS1=192.168.1.2
```

3.配置windows网络适配器，注意几个地方的网关地址和dns地址得一致，否则无法使用外网
![image](https://b3logfile.com/file/2023/03/solo-fetchupload-8702670975168992551-Am8rUgT.png)

4.配置主机名
`hostnamectl --static set-hostname master`

5.配置主机名映射

```
vim /etc/hosts
-- 添加以下内容
192.168.1.101 master
192.168.1.102 slave1
192.168.1.103 slave2
```

5.1.关闭防火墙

```
-- 关闭防火墙
systemctl stop firewalld
-- 开机不启动
systemctl disable firewalld
```

5.2.配置普通用户拥有root权限

```
vim /etc/sudoers
-- 在%wheel下面添加普通用户（lihai）
lihai   ALL=(ALL)     NOPASSWD: ALL
```

5.3.重启虚拟机

6.克隆虚拟机，右键已经创建好的虚拟机名称-》管理-》克隆

下一步
![image](https://b3logfile.com/file/2023/03/solo-fetchupload-4819720170902360046-TidHdvT.png)
下一步
![image](https://b3logfile.com/file/2023/03/solo-fetchupload-15013542080931487948-Cgwhxhm.png)
创建完整克隆，下一步
![image](https://b3logfile.com/file/2023/03/solo-fetchupload-10457217956230913707-oI6aMqq.png)
设置虚拟机名称和位置，点击完成
![image](https://b3logfile.com/file/2023/03/solo-fetchupload-6958223361165293248-sstdHYQ.png)

7.修改克隆的虚拟机ip和主机名，见步骤2，步骤4

## 配置免密登录

1. master节点配置root用户免密登录到master，slave1，slave2
2. master节点配置普通用户免密登录到master，slave1，slave2
3. slave1节点配置普通用户免密登录到master，slave1，slave2

```
ssh-keygen -t rsa --连敲三个回车
ssh-copy-id master --根据提示输入yes，master的密码
ssh-copy-id slave1 --根据提示输入yes，slave1的密码
ssh-copy-id slave2 --根据提示输入yes，slave2的密码
-- 每个步骤都需要执行上面的所有命令
```

## 配置分发脚本，普通用户登录

`vim /home/lihai(这里是普通用户名)/bin/xsync`

```
#!/bin/bash
#1. 判断参数个数
if [ $# -lt 1 ]
then
  echo Not Enough Arguement!
  exit;
fi
#2. 遍历集群所有机器
for host in master slave1 slave2
do
  echo ====================  $host  ====================
  #3. 遍历所有目录，挨个发送
  for file in $@
  do
    #4 判断文件是否存在
    if [ -e $file ]
    then
      #5. 获取父目录
      pdir=$(cd -P $(dirname $file); pwd)
      #6. 获取当前文件的名称
      fname=$(basename $file)
      ssh $host "mkdir -p $pdir"
      rsync -av $pdir/$fname $host:$pdir
    else
      echo $file does not exists!
    fi
  done
done
```

修改脚本具有执行权限
`chmod u+x xsync`

测试脚本
`xsync xsync`

## 配置Java环境

0. 新建两个目录：
   * /opt/module:软件安装目录
   * /opt/software:软件包存放目录
   * 修改目录权限为普通用户（lihai）：chown lihai:lihai /opt/module /opt/software
1. 上传tar包到master
2. 解压`tar -zxvf jdk-8u212-linux-x64.tar.gz -C /opt/module/<span> </span>`
3. 配置环境变量
   `sudo vim /etc/profile.d/my_env.sh`

```
#JAVA_HOME
export JAVA_HOME=/opt/module/jdk1.8.0_212
export PATH=$PATH:$JAVA_HOME/bin
```

4. 使环境变量生效
   `source /etc/profile.d/my_env.sh`
5. 验证是否成功
   `java -version`
6. 分发jdk
   `xsync /opt/module/jdk1.8.0_212/`
7. 分发环境变量配置
   `sudo /home/lihai/bin/xsync /etc/profile.d/my_env.sh`
8. 在slave1，slave2中使环境变量生效
   `source /etc/profile.d/my_env.sh`
