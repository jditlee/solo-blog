title: 【chatgpt】开源类chatgpt项目汇总
date: '2023-03-31 18:22:13'
updated: '2023-04-11 14:46:38'
tags: [ChatGPT, ML, LLAMA, 开源]
permalink: /articles/2023/03/31/1680258133658.html
---
## 1.ColossalChat

基于 LLaMA 模型，Colossal-AI 首个开源包含完整 RLHF 流程的类Chat模型复现方案 ColossalChat，是目前最接近 ChatGPT 原始技术路线的实用开源项目!

ColossalChat 能够快速跟进 ChatGPT 完整 RLHF 流程复现，离不开 AI 大模型基础设施 Colossal-AI 及相关优化技术的底座支持，相同条件下训练速度相比 Alpaca 采用的 FSDP(Fully Sharded Data Parallel) 可提升两倍以上。

AI 大模型开发系统 Colossal-AI 为该方案提供了基础支持，它可基于 PyTorch 高效快速部署 AI 大模型训练和推理，从而降低 AI 大模型应用的成本。

开源地址：https://github.com/hpcaitech/ColossalAI

包含以下内容

1. Demo：可直接在线体验模型效果，无需注册或 waitinglist；
2. 训练代码：开源完整 RLHF 训练代码，已开源至含 7B 和 13B 两种模型；
3. 数据集：开源 104K 中、英双语数据集；
4. 推理部署：4bit 量化推理 70 亿参数模型仅需 4GB 显存；
5. 模型权重：仅需单台服务器少量算力即可快速复现；
6. 更大规模模型、数据集、其他优化等将保持高速迭代添加。

ColossalChat 仅需不到百亿参数，在大语言模型的基础上进行 RLHF 微调，即可掌握中、英双语能力，达到与 ChatGPT 和 GPT-3.5 类似的效果。

在获得最终模型权重后，还可通过量化降低推理硬件成本，并启动在线推理服务，仅需单张约 4GB 显存的 GPU 即可完成 70 亿参数模型推理服务部署

## 2.Alpaca

斯坦福的 Alpaca 通过调用OpenAI API，以 self-instruct 方式生成训练数据，使得仅有 70 亿参数的轻量级模型以极低成本微调后，即可获得媲美 GPT-3.5 这样千亿参数的超大规模语言模型的对话效果。

Alpaca 的训练数据集过小，语料只有英文，也在一定程度上限制了模型的性能。

开源地址：[tatsu-lab/stanford_alpaca: Code and documentation to train Stanford&#39;s Alpaca models, and generate the data. (github.com)](https://github.com/tatsu-lab/stanford_alpaca)

## 3.LLaMA

LLaMA并没有通过人类反馈强化学习（RLHF）训练过程对任务进行微调

* 13B参数的版本在多项基准上测试的效果好于2020年的参数规模达175B的GPT-3
* 65B参数的LLaMA，则可与DeepMind的Chinchilla(70B参数)和谷歌的PaLM(540B参数)旗鼓相当
* 且Meta还尝试使用了论文「Scaling Instruction-Finetuned Language Models」中介绍的指令微调方法，由此产生的模型LLaMA-I，在MMLU(Massive Multitask Language Understanding，大型多任务语言理解)上要优于Google的指令微调模型Flan-PaLM-cont(62B)

开源地址：[facebookresearch/llama: Inference code for LLaMA models (github.com)](https://github.com/facebookresearch/llama)

## 4.BELLE

本项目目标是促进中文对话大模型开源社区的发展。现阶段本项目基于BLOOM针对中文做了优化，模型调优仅使用由ChatGPT生产的数据（不包含任何其他数据）。

局限性和使用限制

基于当前数据和基础模型训练得到的SFT模型，在效果上仍存在以下问题：

1. 在涉及事实性的指令上可能会产生违背事实的错误回答。
2. 对于具备危害性的指令无法很好的鉴别，由此会产生危害性言论。
3. 在一些涉及推理、代码等场景下模型的能力仍有待提高。

基于以上模型局限性，我们要求开发者仅将我们开源的代码、数据、模型及后续用此项目生成的衍生物用于研究目的，不得用于商业，以及其他会对社会带来危害的用途。

开源地址：[LianjiaTech/BELLE: BELLE: BE Large Language model Engine（开源中文对话大模型） (github.com)](https://github.com/LianjiaTech/BELLE)

## 5.ChatLLaMA

基于 LLaMA 的 ChatGPT 的开源实现可在单个 GPU 中运行,不支持中文

* 一个完整的开源实现，使您能够基于预先训练的 LLaMA 模型构建 ChatGPT 风格的服务。
* 与原始的 ChatGPT 相比，通过利用 LLaMA 架构的较小尺寸，训练过程和单 GPU 推理更快、更便宜。
* ChatLLaMA内置了对DeepSpeed ZERO的支持，以加快微调过程。
* 该库还支持所有 LLaMA 模型架构（7B、13B、33B、65B），因此您可以根据训练时间和推理性能的偏好对模型进行微调。

开源地址：[juncongmoo/chatllama：ChatLLaMA 基于 LLaMA 📢 的 ChatGPT 的开源实现，可在单个 GPU 中运行。训练过程比 ChatGPT 快 15 倍 (github.com)](https://github.com/juncongmoo/chatllama)
