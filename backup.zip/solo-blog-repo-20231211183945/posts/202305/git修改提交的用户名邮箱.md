title: git修改提交的用户名邮箱
date: '2023-05-24 15:26:15'
updated: '2023-05-24 15:26:15'
tags: [git, github]
permalink: /articles/2023/05/24/1684913175528.html
---
# git修改提交的用户名邮箱

最近搞了个开源项目，发现提交到GitHub上的用户名邮箱是公司的，然后就需要修改了

本地项目目录下打开git bash here

查看一下git日志：

`git log`

![image.png](https://b3logfile.com/file/2023/05/image-qOPmV4e.png)

然后就是修改项目的用户名邮箱了，修改过后以后提交都是修改的用户名邮箱了

```shell
git config user.name "your name"
git config user.email "your email"
```

如果需要修改全局的，增加`--global`参数就行了

修改最近一次的commit的用户名邮箱，注意`<>`不能少：

```
git commit --amend --author="yourname <yourname>"
```

批量修改：

新建脚本文件`email.sh`并写入以下内容：

```shell
#!/bin/sh

git filter-branch --env-filter '

OLD_EMAIL="old@xx.com"
CORRECT_NAME="yourname"
CORRECT_EMAIL="youremail"

if [ "$GIT_COMMITTER_EMAIL" = "$OLD_EMAIL" ]
then
    export GIT_COMMITTER_NAME="$CORRECT_NAME"
    export GIT_COMMITTER_EMAIL="$CORRECT_EMAIL"
fi
if [ "$GIT_AUTHOR_EMAIL" = "$OLD_EMAIL" ]
then
    export GIT_AUTHOR_NAME="$CORRECT_NAME"
    export GIT_AUTHOR_EMAIL="$CORRECT_EMAIL"
fi
' --tag-name-filter cat -- --branches --tags
```

执行脚本文件，`./email.sh`，注意需要在git bash窗口执行

![image.png](https://b3logfile.com/file/2023/05/image-4wB6OHD.png)

如果报错`Cannot rewrite branches: You have unstaged changes`

执行`git stash`执行再次执行脚本就ok了

此时查看`git log`确认邮箱用户名都修改正确了之后，

然后就可以push了，`git push origin main --force`

建议此方法仅用于个人项目，如果是公司项目，容易冲突，不可取！
